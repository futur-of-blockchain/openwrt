# blockchain-lora-wifi-gateway

## Coding style

* No complex one liner statements. Break them into multiple lines for better readability.
  Even for `if` statements on errors.
  So no `;`.
* Englmish only
* No named returns

## Dependencies

* Docker
* Make
* ProtoBuf Compiler (`protoc`) >= v3.0.0

## Before build

Pull the proto submodule:

```bash
git submodule update --init --recursive
```

Build the Go protobuf decoder and encoder:

```bash
make proto
```