#!/usr/bin/env bash
# Mosquitto conf
readonly PORT=1883
readonly HOST="localhost"

# Pub sub a persistent message to mosquitto broker and receive it
# -C1 option to receive only one message
readonly persistant_topic="test/persistence"
mosquitto_sub -h $HOST -p $PORT -t $persistant_topic -C 1 &
mosquitto_pub -h $HOST -p $PORT -t $persistant_topic -m "Persistant test message" -r

# Same with non persistent message
readonly no_persistant_topic="test/no-persistence"
mosquitto_sub -h $HOST -p $PORT -t $no_persistant_topic -C 1 &
mosquitto_pub -h $HOST -p $PORT -t $no_persistant_topic -m "None persistant test message"
