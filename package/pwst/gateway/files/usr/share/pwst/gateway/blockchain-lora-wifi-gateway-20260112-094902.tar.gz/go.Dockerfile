# --- Build stage ---
FROM golang:1.24-alpine AS builder

# Define app directory
ENV APP_DIR=/app
ENV BIN_DIR=${APP_DIR}/bin
WORKDIR ${APP_DIR}

# Copy go modules and download deps first
COPY go.mod ./

# Copy source code
COPY *.go ./
COPY proto/ ./proto/
COPY gologger/ ./gologger/
COPY gomqttclient/ ./gomqttclient/
COPY gopub/ ./gopub/
COPY gosub/ ./gosub/
COPY gotopics/ ./gotopics/
COPY gomeshtasticcrypto/ ./gomeshtasticcrypto/
COPY gomeshradio/ ./gomeshradio/
COPY gocrypto/ ./gocrypto/

# Build proto after installing protoc and the go generator
RUN apk update && apk add make protobuf-dev
RUN go install google.golang.org/protobuf/cmd/protoc-gen-go@latest
RUN cd proto && protoc --go_out=. --go_opt=paths=source_relative ./*.proto

# Build static binary
RUN go mod download
RUN go mod tidy
RUN CGO_ENABLED=0 GOOS=linux go build -o ${BIN_DIR}/mosquitto_pubsub ./mosquitto_pubsub.go


# --- Production stage (smallest possible) ---
FROM alpine AS prod

ENV APP_DIR=/app
ENV BIN_DIR=${APP_DIR}/bin
WORKDIR ${APP_DIR}

# Add basic tools for inspection
#RUN apk add --no-cache bash curl netcat-openbsd

COPY --from=builder ${BIN_DIR}/mosquitto_pubsub ${BIN_DIR}/mosquitto_pubsub
COPY ./docker.env ./

ENTRYPOINT ["/app/bin/mosquitto_pubsub", "--env=/app/docker.env"]
