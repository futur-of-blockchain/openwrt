package gocrypto

import (
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/math"
)

// TokenBalance The balance of a given token at a given timestamp
type TokenBalance struct {
	TickerSymbol string
	Balance      math.Decimal256
	TS           uint64
}

// WalletInfo All the info about a wallet, nonce and balance
type WalletInfo struct {
	Address common.Address
	Nonce   uint64
	// Array of token balances
	Balances []TokenBalance
}
