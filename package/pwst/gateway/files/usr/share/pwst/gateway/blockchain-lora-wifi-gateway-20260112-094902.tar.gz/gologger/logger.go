package gologger

import (
	"log"
	"os"
)

var (
	Warning *log.Logger
	Info    *log.Logger
	Error   *log.Logger
)

func init() {
	const format int = log.Ldate | log.Ltime | log.Lshortfile
	outputFile := os.Stdout
	Info = log.New(
		outputFile,
		"INFO: ",
		format,
	)
	Warning = log.New(
		outputFile,
		"WARNING: ",
		format,
	)
	Error = log.New(
		outputFile,
		"ERROR: ",
		format,
	)
}

const SEPARATOR = "****************************************************************************************************"
