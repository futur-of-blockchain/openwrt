package gomeshradio

import (
	"bytes"
	"encoding/binary"

	// Standard library imports
	"fmt"
	"sync"
	"sync/atomic"
	"time"
	// Local modules
	log "pwstgateway/gologger"
	"pwstgateway/proto"
	// Distant modules
	"github.com/howeyc/crc16"
	"github.com/phe-sto/gomesh"
	"github.com/phe-sto/gomesh/github.com/meshtastic/gomeshproto"
)

var (
	// manager manages shared radio access
	manager = &radioManager{
		activeRequests: 0,
		port:           "",
	}
)

// radioManager encapsulates radio lifecycle management
type radioManager struct {
	mu             sync.Mutex
	radio          *gomesh.Radio
	port           string
	isOpen         bool
	activeRequests int32
	shuttingDown   bool
}

// InitMeshtasticRadio initializes the radio and prevents closing it while in use
func InitMeshtasticRadio(port string) error {
	manager.mu.Lock()
	defer manager.mu.Unlock()

	if manager.shuttingDown {
		return fmt.Errorf("system is shutting down")
	}

	// Store port for reinitialization
	manager.port = port

	if manager.isOpen {
		return nil // Already initialized
	}

	// Create new Radio instance
	manager.radio = &gomesh.Radio{}
	err := manager.radio.Init(port)
	if err != nil {
		return fmt.Errorf("radio initialization failed: %w", err)
	}

	manager.isOpen = true
	log.Info.Printf("Radio initialized on port %s", port)
	return nil
}

// withRadio allows executing operations on the radio safely
func withRadio(operation func(*gomesh.Radio) error) error {
	// Acquire the radio and increment active requests counter
	radio, err := acquireRadio()
	if err != nil {
		return err
	}

	// Decrement the counter when finished
	defer releaseRadio()

	// Execute the operation with the radio
	return operation(radio)
}

// ReadResponses reads responses from the Meshtastic device in a thread-safe manner
func ReadResponses() ([]*gomeshproto.FromRadio, error) {
	var responses []*gomeshproto.FromRadio

	err := withRadio(func(radio *gomesh.Radio) error {
		resp, err := radio.ReadResponse(true)
		if err != nil {
			return err
		}
		responses = resp
		return nil
	})

	return responses, err
}

// acquireRadio prepares the radio for use
func acquireRadio() (*gomesh.Radio, error) {
	manager.mu.Lock()
	defer manager.mu.Unlock()

	if manager.shuttingDown {
		return nil, fmt.Errorf("system is shutting down")
	}

	// Check and reinitialize radio if needed
	if !manager.isOpen && manager.port != "" {
		manager.radio = &gomesh.Radio{}
		radioManagerErr := manager.radio.Init(manager.port)
		if radioManagerErr != nil {
			return nil, fmt.Errorf(
				"reinitialization failed: %w",
				radioManagerErr,
			)
		}
		manager.isOpen = true
		log.Info.Printf("Radio reinitialized on %s", manager.port)
	}

	if !manager.isOpen {
		return nil, fmt.Errorf("radio not initialized")
	}

	// Increment active requests counter
	atomic.AddInt32(&manager.activeRequests, 1)
	return manager.radio, nil
}

// releaseRadio indicates that the radio operation has completed
func releaseRadio() {
	atomic.AddInt32(&manager.activeRequests, -1)
}

// SendPacket sends a packet via the radio in a thread-safe manner
func SendPacket(payload []byte) error {
	return withRadio(func(radio *gomesh.Radio) error {
		return radio.SendPacket(payload)
	})
}

// CloseRadio closes the radio only if no operations are in progress
func CloseRadio() {
	manager.mu.Lock()
	defer manager.mu.Unlock()

	// Mark as shutting down
	manager.shuttingDown = true

	// Wait for all operations to complete (with timeout)
	deadline := time.Now().Add(5 * time.Second)
	for atomic.LoadInt32(&manager.activeRequests) > 0 {
		manager.mu.Unlock() // Release mutex during wait
		time.Sleep(100 * time.Millisecond)
		manager.mu.Lock()

		if time.Now().After(deadline) {
			log.Info.Printf("Timeout waiting for operations to complete (%d active)",
				atomic.LoadInt32(&manager.activeRequests))
			break
		}
	}

	// Close radio if it's open
	if manager.isOpen && manager.radio != nil {
		log.Info.Printf("Closing radio on %s", manager.port)
		manager.radio.Close()
		manager.isOpen = false
	}
}

// WrapInEnvelope wraps a serialized payload proto into an Envelope proto with the payload type.
func WrapInEnvelope(payloadProto []byte, payloadType proto.PayloadType) (*proto.Envelope, error) {
	// Create a new Envelope instance
	envelope := &proto.Envelope{
		Type:    payloadType,
		Payload: payloadProto,
	}

	// Calculate CRC16 checksum
	var buffer bytes.Buffer
	buffer.WriteByte(byte(payloadType)) // Write the payload type as a single byte
	buffer.Write(payloadProto)          // Write the serialized payload
	crc := crc16.ChecksumCCITTFalse(buffer.Bytes())

	// Convert CRC16 to 2 bytes and set it in the envelope
	crcBytes := make([]byte, 2)
	binary.BigEndian.PutUint16(crcBytes, crc)
	envelope.Crc16 = crcBytes

	return envelope, nil
}
