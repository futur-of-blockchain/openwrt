package gomeshtasticcrypto

import (
	"fmt"

	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/rlp"
)

/*
DecodeMeshtasticPayload attempts to decode a Meshtastic payload as an Ethereum
transaction using RLP decoding. It takes a byte slice as input and returns a
boolean indicating whether the decoding was successful.

Parameters:

- payload: A byte slice containing the Meshtastic payload to be decoded.

Returns: The Tx and the error, either nil or the error occurred during
decoding.
*/
func DecodeMeshtasticPayload(payload *[]byte) (*types.Transaction, error) {
	if payload == nil {
		return nil, fmt.Errorf("payload is nil")
	}
	var tx *types.Transaction
	err := rlp.DecodeBytes(*payload, &tx)
	if err == nil {
		return tx, nil
	} else {
		return nil, err
	}
}
