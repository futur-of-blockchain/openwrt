package gomqttclient

import (
	// Standard library
	"fmt"
	log "pwstgateway/gologger"

	// Form outside modules
	mqtt "github.com/eclipse/paho.mqtt.golang"
)

type MQTTClient struct {
	client mqtt.Client
}

func NewMQTTClient(
	broker string,
	port uint16,
	clientID string,
	username string,
	password string,
) *MQTTClient {
	opts := mqtt.NewClientOptions()
	opts.AddBroker(fmt.Sprintf("tcp://%s:%d", broker, port))
	opts.SetClientID(clientID)
	opts.SetUsername(username)
	opts.SetPassword(password)
	opts.SetDefaultPublishHandler(messagePubHandler)
	opts.OnConnect = connectHandler
	opts.OnConnectionLost = connectLostHandler
	opts.SetWill(
		"client/status",
		"Abnormally disconnected",
		1,
		true,
	)

	client := mqtt.NewClient(opts)
	token := client.Connect()
	token.Wait()
	tokenErr := token.Error()
	if tokenErr != nil {
		panic(tokenErr)
	}

	return &MQTTClient{client: client}
}

// Publication represents a message to be published
type Publication struct {
	Topic   string
	Retain  bool
	Payload []byte
}

// Publish a message to a topic
func (c *MQTTClient) Publish(pub Publication) mqtt.Token {
	log.Info.Println("Publish topic: ", pub.Topic)
	return c.client.Publish(pub.Topic, 2, pub.Retain, pub.Payload)
}

// Subscription represents a subscription to a topic
type Subscription struct {
	Topic    string
	Callback mqtt.MessageHandler
}

// Subscribe to a topic
func (c *MQTTClient) Subscribe(sub Subscription) mqtt.Token {
	return c.client.Subscribe(sub.Topic, 2, sub.Callback)
}

// Disconnect the client
func (c *MQTTClient) Disconnect(quiesce uint) {
	c.client.Disconnect(quiesce)
}

var messagePubHandler mqtt.MessageHandler = func(
	client mqtt.Client,
	msg mqtt.Message,
) {
	log.Info.Printf(
		"Received message: %s from topic: %s\n",
		msg.Payload(), msg.Topic(),
	)
}

var connectHandler mqtt.OnConnectHandler = func(client mqtt.Client) {
	log.Info.Println("Connected")
}

var connectLostHandler mqtt.ConnectionLostHandler = func(
	client mqtt.Client,
	err error,
) {
	log.Error.Printf("Connect lost: %v", err)
}
