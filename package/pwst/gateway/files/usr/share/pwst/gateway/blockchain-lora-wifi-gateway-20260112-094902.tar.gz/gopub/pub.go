// Package gopub
package gopub

import (
	// Standard library imports
	"context"
	"encoding/binary"
	"time"
	// Local modules
	log "pwstgateway/gologger"
	"pwstgateway/gomeshtasticcrypto"
	"pwstgateway/gomqttclient"
	"pwstgateway/gotopics"
	"pwstgateway/proto"

	"pwstgateway/gomeshradio"

	"github.com/arduino/go-xmodem/xmodem"
	// Distant modules
	"github.com/phe-sto/gomesh/github.com/meshtastic/gomeshproto"
	protobuf "google.golang.org/protobuf/proto"
)

/*
loopWithDefault is a helper function to run a loop with a default case in a
select statement. It takes a context to handle cancellation, a stop message to
log when the context is done, an error prefix to log in case of an error, and
a function to execute in the loop.
The function will run indefinitely until the context is cancelled or an error.
To use with all the publication functions.

Parameters:

- ctx: A context.Context object to manage cancellation of the goroutine.

- stopMsg: A string message to log when the context is done.

- errPrefix: A string prefix to log in case of an error.

- fn: A function that returns an error, to be executed in the loop.

Returns: None. Logs messages based on context cancellation or errors from the
function.
*/
func loopWithDefault(
	ctx context.Context,
	stopMsg,
	errPrefix string,
	fn func() error,
) {
	for {
		select {
		case <-ctx.Done():
			log.Info.Println(stopMsg)
			return
		default:
			funErr := fn()
			if funErr != nil {
				log.Error.Printf("%s: %v\n", errPrefix, funErr)
				return
			}
		}
	}
}

/*
PublishTime publishes the current time every second to the MQTT broker. For
testing purposes only. The function runs until the provided context is
cancelled.

Parameters:

- ctx: A context.Context object to manage cancellation of the goroutine.

- client: A pointer to a gomqttclient.MQTTClient instance for publishing messages

Returns: Errors encountered during serialization or publishing are logged
*/
func PublishTime(ctx context.Context, client *gomqttclient.MQTTClient) {
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	loopWithDefault(ctx, "Stopping publication", "Serialisation error", func() error {
		t := <-ticker.C

		// Create a protobuf message with the timestamp
		nowProto := &proto.Now{
			Timestamp: t.Unix(),
		}

		// Serialize the protobuf message
		payload, marshallErr := protobuf.Marshal(nowProto)
		if marshallErr != nil {
			return marshallErr
		}

		Publish(client, gotopics.TimeNow, payload)
		return nil
	})
}

/*
PublishReceivedMeshtasticRx reads messages from a Meshtastic device via a serial
port and publishes them to an MQTT broker. It listens for incoming messages on
the specified serial port, processes them, and if they are on the PRIVATE_APP
port, it publishes the payload to the "meshtastic/Rx" topic on the MQTT broker.
The function runs until the provided context is cancelled.

Parameters:

- ctx: A context.Context object to manage cancellation of the goroutine.

- client: A pointer to a gomqttclient.MQTTClient instance for publishing messages.

- meshtasticSerialPort: A string representing the serial port of the Meshtastic device.

Returns: Errors encountered during reading from the Meshtastic device or publishing to
the MQTT broker are logged.

Note: Ensure that the Meshtastic device is properly connected and configured to
communicate over the specified serial port before running this function.
*/
func PublishReceivedMeshtasticRx(
	ctx context.Context,
	client *gomqttclient.MQTTClient,
	meshtasticSerialPort string,
) {
	radioInitErr := gomeshradio.InitMeshtasticRadio(meshtasticSerialPort)
	if radioInitErr != nil {
		log.Error.Printf(
			"Failed to initialize Meshtastic radio on port %s: %v\n",
			meshtasticSerialPort,
			radioInitErr,
		)
		return
	}

	loopWithDefault(ctx, "Stopping Meshtastic RX", "Meshtastic radio error", func() error {
		responses, responseErr := gomeshradio.ReadResponses()
		if responseErr != nil {
			return responseErr
		}

		for _, response := range responses {
			packet := response.GetPacket()
			if packet == nil {
				continue
			}

			payloadVariant := packet.GetPayloadVariant()
			if payloadVariant == nil {
				continue
			}

			switch variant := payloadVariant.(type) {
			case *gomeshproto.MeshPacket_Decoded:
				if variant.Decoded == nil || len(variant.Decoded.Payload) == 0 {
					log.Error.Println("Decoded payload is empty")
					continue
				}
				if variant.Decoded.Portnum == gomeshproto.PortNum_PRIVATE_APP {

					// Decoded using the Envelope protobuff
					var envelope proto.Envelope
					err := protobuf.Unmarshal(variant.Decoded.Payload, &envelope)
					if err != nil {
						log.Error.Printf(
							"Failed to unmarshal Meshtastic payload into Envelope: %v\n",
							err,
						)
						continue
					}

					// CRC16 xmodem checksum verification
					buf := []byte{byte(envelope.Type)}
					buf = append(buf, envelope.Payload...)
					crc16 := xmodem.CRC16(buf)
					envelopeCrc16 := binary.BigEndian.Uint16(envelope.Crc16)
					if crc16 == envelopeCrc16 {
						log.Info.Println("CRC16 checksum valid")
						// Frame is valid, proceed
					} else {
						// Invalid frame, discard, go to next
						log.Error.Println("CRC16 checksum invalid")
						continue
					}

					// Find the topic based on the payload type
					var topic string
					switch envelope.Type {
					case proto.PayloadType_PAYLOAD_TYPE_ETH_TX:
						if decodeMeshtasticTxPayload(&envelope.Payload) == true {
							topic = gotopics.MeshtasticTx
						} else {
							log.Error.Println(
								"failed to decode Meshtastic Ethereum RLP transaction payload",
							)
							continue
						}
					case proto.PayloadType_PAYLOAD_TYPE_WALLET_ID:
						topic = gotopics.MeshtasticWalletId
					default:
						log.Error.Printf(
							"Unknown payload type: %v. Skipping publish.\n",
							envelope.Type,
						)
						continue
					}
					// Publish the payload to the appropriate topic on MQTT broker
					Publish(
						client,
						topic,
						envelope.Payload,
					)
					log.Info.Printf(
						"Published on topic %s payload size %d: %x\n",
						topic,
						len(envelope.Payload),
						envelope.Payload,
					)
				}
			default:
				log.Error.Printf("Unknown payload variant")
			}
		}
		return nil
	})
}

/*
decodeMeshtasticTxPayload attempts to decode a Meshtastic payload as an Ethereum
transaction using RLP decoding. It takes a byte slice as input and returns a
boolean indicating whether the decoding was successful.

If the decoding is successful, it logs the transaction hash; otherwise, it logs
an error message.

Parameters:

- payload: A byte slice containing the Meshtastic payload to be decoded.

Returns: A boolean value indicating whether the decoding was successful.
True if successful, false otherwise.
*/
func decodeMeshtasticTxPayload(payload *[]byte) bool {
	if payload == nil {
		return false
	}
	tx, decodeError := gomeshtasticcrypto.DecodeMeshtasticPayload(payload)
	if decodeError == nil {
		hash := tx.Hash().Bytes()
		log.Info.Printf(
			"Decoded Meshtastic payload, Tx hash: 0x%x\n",
			hash,
		)
		return true
	} else {
		log.Error.Println("Failed to decode transaction")
		return false
	}
}

/*
Publish is a helper function to Publish a message to a specified MQTT topic.

It takes a pointer to an MQTT client, the topic string, and the payload as a
byte slice. The function constructs a publication object, sends it using the
client's Publish method, and waits for the operation to complete. If an error
occurs during publishing, it logs the error; otherwise, it logs a success message.

Parameters:

- client: A pointer to a gomqttclient.MQTTClient instance used for publishing.

- topic: A string representing the MQTT topic to Publish to.

- payload: A byte slice containing the message payload to be published.
*/
func Publish(client *gomqttclient.MQTTClient, topic string, payload []byte) {
	publication := gomqttclient.Publication{
		Topic:   topic,
		Retain:  false,
		Payload: payload,
	}

	token := client.Publish(publication)
	token.Wait()

	tokenErr := token.Error()
	if tokenErr != nil {
		log.Error.Printf("Publication error: %v\n", tokenErr)
		return
	}
	log.Info.Printf("Published on %s (%d bytes)\n", topic, len(payload))
}
