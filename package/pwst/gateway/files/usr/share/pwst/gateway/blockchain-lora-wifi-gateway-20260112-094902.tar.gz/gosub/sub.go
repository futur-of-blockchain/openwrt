package gosub

import (
	// Standard library imports and local modules
	"context"
	"crypto/rand"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"math/big"
	"pwstgateway/gocrypto"
	log "pwstgateway/gologger"
	"pwstgateway/gomeshradio"
	"pwstgateway/gomeshtasticcrypto"
	"pwstgateway/gomqttclient"
	"pwstgateway/gopub"
	"pwstgateway/gotopics"
	"pwstgateway/proto"
	"sync"
	"time"

	// Distant modules
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/common/hexutil"
	"github.com/ethereum/go-ethereum/common/math"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/rpc"
	pb "github.com/phe-sto/gomesh/github.com/meshtastic/gomeshproto"
	protobuf "google.golang.org/protobuf/proto"
)

/*
subscribeWithHandler factorises the common subscribe flow.
It wraps the provided handler with a mutex to ensure thread-safety,
subscribes to the topic, and blocks until ctx is cancelled.

Parameters:

- ctx: A context.Context to manage cancellation of the subscription.

- client: A pointer to the MQTTClient used for subscribing.

- topic: The topic string to subscribe to.

- handler: The mqtt.MessageHandler function to handle incoming messages.
*/
func subscribeWithHandler(
	ctx context.Context,
	client *gomqttclient.MQTTClient,
	topic string,
	handler mqtt.MessageHandler,
) {
	var mu sync.Mutex

	wrapped := func(c mqtt.Client, m mqtt.Message) {
		mu.Lock()
		defer mu.Unlock()
		handler(c, m)
	}

	subscription := gomqttclient.Subscription{
		Topic:    topic,
		Callback: wrapped,
	}

	token := client.Subscribe(subscription)
	token.Wait()
	tokenErr := token.Error()
	if tokenErr != nil {
		log.Error.Printf(
			"Subscription error on %s: %v\n",
			topic,
			tokenErr,
		)
		return
	}
	log.Info.Printf("Subscribed to topic %s", topic)

	<-ctx.Done()
	log.Info.Printf("Stopping topic %s subscription", topic)
}

/*
SubscribeTime subscribes to the TimeNow topic and processes incoming messages.
It deserializes the Protobuf message and logs the timestamp.

Parameters:

- ctx: A context.Context to manage cancellation of the subscription.

- client: A pointer to the MQTTClient used for subscribing.
*/
func SubscribeTime(ctx context.Context, client *gomqttclient.MQTTClient) {
	handler := func(_ mqtt.Client, msg mqtt.Message) {
		// Protobuf deserialization
		nowMsg := &proto.Now{}
		unmarshalErr := protobuf.Unmarshal(msg.Payload(), nowMsg)
		if unmarshalErr != nil {
			log.Error.Printf(
				"Protobuf deserialization error: %v\n", unmarshalErr,
			)
			return
		}

		// Print decoded timestamp
		log.Info.Printf(
			"Message received on %s: timestamp=%d\n",
			msg.Topic(),
			nowMsg.GetTimestamp(),
		)
	}

	subscribeWithHandler(ctx, client, gotopics.TimeNow, handler)
}

/*
ethereumTxResponsePayload structure equivalent to the proto message
ethRpcResponse.
*/
type ethereumTxResponsePayload struct {
	Error  string      `json:"error,omitempty"`
	Code   uint32      `json:"code"`
	TxHash common.Hash `json:"txhash,omitempty"`
}

/*
SubscribeMeshtasticTx subscribes to the MeshtasticTx topic, processes incoming
messages, and sends them as raw Ethereum transactions to the specified ETH
provider.

Parameters:

- ctx: A context.Context to manage cancellation of the subscription.

- client: A pointer to the MQTTClient used for subscribing.

- ethIP: The IP address of the Ethereum provider.

- ethPort: The port of the Ethereum provider.

Returns: Errors encountered during RPC connection or transaction sending are
logged.
*/
func SubscribeMeshtasticTx(
	ctx context.Context,
	client *gomqttclient.MQTTClient,
	ethProviderURL string,
) {
	if ethProviderURL == "" {
		log.Error.Printf("ETH provider URL missing\n")
		return
	}

	handler := func(_ mqtt.Client, msg mqtt.Message) {
		// Convert octets to hex string prefixed with 0x
		payload := msg.Payload()
		rawHex := "0x" + hex.EncodeToString(payload)

		rpcClient, rpcDialError := rpc.DialContext(ctx, ethProviderURL)
		if rpcDialError != nil {
			log.Error.Printf("ETH RPC dial error: %v\n", rpcDialError)
			return
		}
		defer rpcClient.Close()

		/***********************************************************************
		* Logging only. No need to decrypt otherwise
		 */
		tx, decodeErr := gomeshtasticcrypto.DecodeMeshtasticPayload(&payload)
		if decodeErr != nil {
			log.Error.Printf("ETH RLP decode error: %v\n", decodeErr)
			return
		}
		// Print raw tx
		log.Info.Printf("ETH raw tx: %s\n", rawHex)
		// Print tx hash
		hash := tx.Hash()
		hashHex := hash.Hex()
		log.Info.Println(log.SEPARATOR)
		log.Info.Printf("ETH tx hash: %s\n", hashHex)
		// Print gas price
		gas := tx.GasPrice()
		log.Info.Printf("ETH tx gas price: %s\n", gas.String())
		// Print gas limit
		gasLimit := tx.Gas()
		log.Info.Printf("ETH tx gas limit: %d\n", gasLimit)
		// Receiver address
		to := tx.To()
		if to != nil {
			log.Info.Printf("ETH tx receiver: %s\n", to.Hex())
		} else {
			log.Info.Printf("ETH tx receiver: contract creation\n")
		}
		// Value
		value := tx.Value()
		log.Info.Printf("ETH tx value: %s\n", value.String())
		// Nonce
		log.Info.Printf("ETH tx nonce: %d\n", tx.Nonce())
		// Data
		log.Info.Printf("ETH tx data: %x\n", tx.Data())
		// V, R, S
		V, R, S := tx.RawSignatureValues()
		log.Info.Printf("ETH tx V: %s\n", V.String())
		log.Info.Printf("ETH tx R: %s\n", R.String())
		log.Info.Printf("ETH tx S: %s\n", S.String())
		// Sender address
		signer := types.LatestSignerForChainID(tx.ChainId())
		from, _ := types.Sender(signer, tx)
		log.Info.Printf("Derived sender: %s\n", from.Hex())
		log.Info.Println(log.SEPARATOR)

		/***********************************************************************
		* Send the raw transaction
		 */
		rpcError := rpcClient.CallContext(
			ctx,
			&hash,
			"eth_sendRawTransaction",
			rawHex,
		)
		log.Info.Printf("ETH tx hash %s sent to blockchain node\n", hashHex)

		/***********************************************************************
		* Handle RPC response and submit it
		 */
		var txPostReturn ethereumTxResponsePayload
		if rpcError != nil { // An ERROR occurred during the RPC call
			errorMessage := fmt.Sprintf("ETH sendRawTransaction error: %v", rpcError)
			log.Error.Println(errorMessage)
			if len(errorMessage) > 200 {
				errorMessage = errorMessage[:200]
			}

			// Return code is one for all errors
			txPostReturn = ethereumTxResponsePayload{
				errorMessage, 1, hash,
			}
		} else { // Transaction sent SUCCESSFULLY
			txPostReturn = ethereumTxResponsePayload{
				"", 0, hash,
			}
		}
		// Serialize the response payload to Protobuf
		responseBytes, marshalErr := protobuf.Marshal(&proto.EthTxRpcResponse{
			// Limit error message size to 200 chars
			Message: txPostReturn.Error,
			Code:    int32(txPostReturn.Code),
			TxHash:  txPostReturn.TxHash.Bytes(),
		})
		// Handle serialization error
		if marshalErr != nil {
			log.Error.Printf(
				"Protobuf serialization error: %v\n",
				marshalErr,
			)
			return
		}

		// Publish the response
		gopub.Publish(
			client,
			gotopics.EthereumTxResponse,
			responseBytes,
		)
	}
	subscribeWithHandler(ctx, client, gotopics.MeshtasticTx, handler)
}

// SubscribeEthereumTxResponse subscribes to the EthereumTxResponse topic and
// sends the ETH tx response over Meshtastic.
func SubscribeEthereumTxResponse(
	ctx context.Context,
	client *gomqttclient.MQTTClient,
	meshtasticSerialPort string,
) {
	handler := func(_ mqtt.Client, msg mqtt.Message) {
		// Protobuf deserialization
		var protoResp proto.EthTxRpcResponse
		unmarshallErr := protobuf.Unmarshal(msg.Payload(), &protoResp)
		if unmarshallErr != nil {
			log.Error.Printf(
				"Protobuf deserialization error: %v\n",
				unmarshallErr,
			)
			return
		}

		// Convert to local structure
		payload := ethereumTxResponsePayload{
			Error:  protoResp.GetMessage(),
			Code:   uint32(protoResp.GetCode()),
			TxHash: common.BytesToHash(protoResp.GetTxHash()),
		}

		radioInitErr := gomeshradio.InitMeshtasticRadio(meshtasticSerialPort)
		if radioInitErr != nil {
			log.Error.Printf(
				"Failed to initialize Meshtastic radio on port %s: %v\n",
				meshtasticSerialPort,
				radioInitErr,
			)
			return
		}

		radioSendErr := sendEthTxRespMessage(msg.Payload())
		if radioSendErr != nil {
			log.Error.Printf(
				"Error sending ETH tx response on Meshtastic: %v\n",
				radioSendErr,
			)
			return
		}
		log.Info.Printf(
			"Message ETH tx response sent over Meshtastic for tx hash: %s\n",
			payload.TxHash.Hex(),
		)
	}

	subscribeWithHandler(ctx, client, gotopics.EthereumTxResponse, handler)
}

// sendEthTxRespMessage sends an ETH tx response message over Meshtastic
func sendEthTxRespMessage(message []byte) error {

	packetID := randomPacketId()

	// Wrap the message in an envelope
	envelope, wrappingError := gomeshradio.WrapInEnvelope(
		message,
		proto.PayloadType_PAYLOAD_TYPE_ETH_TX_RESPONSE,
	)
	if wrappingError != nil {
		log.Error.Printf(
			"Error wrapping ETH tx response in envelope: %v\n", wrappingError,
		)
		return wrappingError
	}

	// Serialize the envelope
	envelopeBytes, marshalErr := protobuf.Marshal(envelope)
	if marshalErr != nil {
		log.Error.Printf(
			"Error serializing ETH tx response envelope: %v\n", marshalErr,
		)
		return marshalErr
	}
	radioMessage := pb.ToRadio{
		PayloadVariant: &pb.ToRadio_Packet{
			Packet: &pb.MeshPacket{
				// Broadcast address, no constant in protobuf
				To:      0xffffffff,
				WantAck: true,
				Id:      packetID,
				PayloadVariant: &pb.MeshPacket_Decoded{
					Decoded: &pb.Data{
						Payload:      envelopeBytes,
						Portnum:      pb.PortNum_PRIVATE_APP,
						WantResponse: false,
					},
				},
			},
		},
	}

	out, marshalErr := protobuf.Marshal(&radioMessage)
	if marshalErr != nil {
		return marshalErr
	}

	sendPacketErr := gomeshradio.SendPacket(out)
	if sendPacketErr != nil {
		return sendPacketErr
	} else {
		log.Info.Printf(
			"ETH tx response Meshtastic packet sent, id: %d\n",
			packetID,
		)
	}
	return nil
}

// SubscribeWalletInfo subscribes to the MeshtasticWalletId topic, processes
// incoming wallet ID requests, queries the ETH provider for nonce and balance,
// and publishes the wallet info to the MeshtasticWalletInfo topic.
func SubscribeWalletInfo(
	ctx context.Context,
	client *gomqttclient.MQTTClient,
	ethProviderURL string,
) {
	handler := func(_ mqtt.Client, msg mqtt.Message) {
		// Protobuf deserialization
		var walletId proto.WalletId
		unmarshallErr := protobuf.Unmarshal(msg.Payload(), &walletId)
		if unmarshallErr != nil {
			log.Error.Printf(
				"Protobuf deserialization error: %v\n",
				unmarshallErr,
			)
			return
		}
		// Query ETH provider using wallet address
		walletAddress := common.BytesToAddress(walletId.GetAddress())
		log.Info.Printf(
			"Received wallet info request for address: %s\n",
			walletAddress.Hex(),
		)
		// Query RPC provider for nonce
		rpcClient, rpcDialError := rpc.DialContext(ctx, ethProviderURL)
		if rpcDialError != nil {
			log.Error.Printf("ETH RPC dial error: %v\n", rpcDialError)
			return
		}
		defer rpcClient.Close()

		// Handle nonce
		var nonceHex string
		nonceErr := rpcClient.CallContext(
			ctx,
			&nonceHex,
			"eth_getTransactionCount",
			walletAddress.Hex(),
			"latest",
		)

		if nonceErr != nil {
			log.Error.Printf(
				"Error getting nonce for address %s: %v\n",
				walletAddress.Hex(),
				nonceErr,
			)
			return
		}
		nonce, decodeErr := hexutil.DecodeUint64(nonceHex)
		if decodeErr != nil {
			log.Error.Printf(
				"Error decoding nonce hex for address %s: %v\n",
				walletAddress.Hex(),
				decodeErr,
			)
			return
		}
		log.Info.Printf(
			"Nonce for address %s: %d\n",
			walletAddress.Hex(),
			nonce,
		)
		// Balance
		var balanceHex string
		balanceErr := rpcClient.CallContext(
			ctx,
			&balanceHex,
			"eth_getBalance",
			walletAddress.Hex(),
			"latest",
		)
		if balanceErr != nil {
			log.Error.Printf(
				"Error getting balance for address %s: %v\n",
				walletAddress.Hex(),
				balanceErr,
			)
			return
		}
		// Use big.Int-compatible decoder to handle values > 64 bits (wei)
		balanceBig, decodeErr := hexutil.DecodeBig(balanceHex)
		if decodeErr != nil {
			log.Error.Printf(
				"Error decoding balance hex for address %s: %v\n",
				walletAddress.Hex(),
				decodeErr,
			)
			return
		}

		log.Info.Printf(
			"Balance for address %s: %s wei\n",
			walletAddress.Hex(),
			balanceBig.String(),
		)

		// Convert *big.Int -> math.HexOrDecimal256
		var balanceDec math.HexOrDecimal256
		unmarshalBalanceErr := balanceDec.UnmarshalText([]byte(balanceBig.String()))
		if unmarshalBalanceErr != nil {
			log.Error.Printf(
				"Error converting balance to HexOrDecimal256 for address %s: %v\n",
				walletAddress.Hex(),
				unmarshalBalanceErr,
			)
			return
		}

		var balances []gocrypto.TokenBalance
		balances = append(balances, gocrypto.TokenBalance{
			TickerSymbol: "SURVIVE",
			Balance:      math.Decimal256(balanceDec),
			TS:           uint64(time.Now().Unix()),
		})

		walletInfo := gocrypto.WalletInfo{
			Address:  walletAddress,
			Nonce:    nonce,
			Balances: balances,
		}
		log.Info.Printf("Wallet info for %s: %+v\n", walletAddress.Hex(), walletInfo)

		// Serialize wallet info to Protobuf
		walletInfoProto := &proto.WalletInfo{
			Address: walletInfo.Address.Bytes(),
			Nonce:   walletInfo.Nonce,
		}
		for _, bal := range walletInfo.Balances {
			// Convert balance to bytes
			bi := new(big.Int)
			decimalString := bal.Balance.String()
			if _, ok := bi.SetString(decimalString, 10); !ok {
				log.Error.Printf(
					"Invalid decimal string: %s",
					decimalString,
				)
				continue
			}
			walletInfoProto.Balances = append(walletInfoProto.Balances, &proto.TokenBalance{
				TickerSymbol: bal.TickerSymbol,
				// 32 bytes for Decimal256
				Balance: common.LeftPadBytes(bi.Bytes(), 32),
				Ts:      bal.TS,
			})
		}
		responseBytes, marshalErr := protobuf.Marshal(walletInfoProto)
		if marshalErr != nil {
			log.Error.Printf(
				"Protobuf serialization error: %v\n",
				marshalErr,
			)
			return
		}

		// Publish wallet info response
		gopub.Publish(
			client,
			gotopics.MeshtasticWalletInfo,
			responseBytes,
		)
		log.Info.Printf(
			"Published wallet info for address %s\n",
			walletAddress.Hex(),
		)
	}

	subscribeWithHandler(ctx, client, gotopics.MeshtasticWalletId, handler)
}

// sendWalletInfoMeshtasticMessage envelopes `message` (proto.WalletInfo bytes)
// and sends it via Meshtastic.
func sendWalletInfoMeshtasticMessage(message []byte) error {

	packetID := randomPacketId()

	// Wrap the message in an envelope (use the wallet info payload type)
	envelope, wrapErr := gomeshradio.WrapInEnvelope(
		message,
		proto.PayloadType_PAYLOAD_TYPE_WALLET_INFO,
	)
	if wrapErr != nil {
		log.Error.Printf("Error wrapping WalletInfo in envelope: %v\n", wrapErr)
		return wrapErr
	}

	// Serialize the envelope
	envelopeBytes, marshalErr := protobuf.Marshal(envelope)
	if marshalErr != nil {
		log.Error.Printf("Error serializing WalletInfo envelope: %v\n", marshalErr)
		return marshalErr
	}

	radioMessage := pb.ToRadio{
		PayloadVariant: &pb.ToRadio_Packet{
			Packet: &pb.MeshPacket{
				To:      0xffffffff,
				WantAck: true,
				Id:      packetID,
				PayloadVariant: &pb.MeshPacket_Decoded{
					Decoded: &pb.Data{
						Payload:      envelopeBytes,
						Portnum:      pb.PortNum_PRIVATE_APP,
						WantResponse: false,
					},
				},
			},
		},
	}

	out, marshalErr := protobuf.Marshal(&radioMessage)
	if marshalErr != nil {
		log.Error.Printf(
			"Error serializing radio message for WalletInfo: %v\n",
			marshalErr,
		)
		return marshalErr
	}

	sendPacketError := gomeshradio.SendPacket(out)
	if sendPacketError != nil {
		log.Error.Printf(
			"Error sending WalletInfo Meshtastic packet: %v\n",
			sendPacketError,
		)
		return sendPacketError
	}

	log.Info.Printf("WalletInfo Meshtastic packet sent, id: %d\n", packetID)
	return nil
}

// SubscribeWalletInfoMeshtastic subscribes to `gotopics.MeshtasticWalletInfo`,
// validates the incoming protobuf and forwards it to the Meshtastic device.
func SubscribeWalletInfoMeshtastic(
	ctx context.Context,
	client *gomqttclient.MQTTClient,
	meshtasticSerialPort string,
) {
	handler := func(_ mqtt.Client, msg mqtt.Message) {

		radioInitErr := gomeshradio.InitMeshtasticRadio(meshtasticSerialPort)
		if radioInitErr != nil {
			log.Error.Printf(
				"Failed to initialize Meshtastic radio on port %s: %v\n",
				meshtasticSerialPort,
				radioInitErr,
			)
			return
		}

		// Validate protobuf
		var wi proto.WalletInfo
		unmarshalError := protobuf.Unmarshal(msg.Payload(), &wi)
		if unmarshalError != nil {
			log.Error.Printf(
				"Protobuf WalletInfo deserialization error: %v\n",
				unmarshalError,
			)
			return
		}

		// Optionally log summary
		log.Info.Printf(
			"Forwarding WalletInfo for nonce=%d balance number=%d\n",
			wi.GetNonce(),
			len(wi.GetBalances()),
		)

		sendError := sendWalletInfoMeshtasticMessage(msg.Payload())
		if sendError != nil {
			log.Error.Printf(
				"Failed to send WalletInfo to Meshtastic: %v\n",
				sendError,
			)
			return
		}
	}

	subscribeWithHandler(ctx, client, gotopics.MeshtasticWalletInfo, handler)
}

// randomPacketId generates a random uint32 packet ID
func randomPacketId() uint32 {
	// Generate a random packet ID
	var b [4]byte
	_, readByteErr := rand.Read(b[:])
	if readByteErr != nil {
		panic(readByteErr)
	}
	return binary.LittleEndian.Uint32(b[:])
}
