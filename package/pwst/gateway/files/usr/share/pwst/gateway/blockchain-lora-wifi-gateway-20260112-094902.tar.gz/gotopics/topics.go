package gotopics

const (
	TimeNow              string = "time/now"
	MeshtasticTx         string = "meshtastic/Tx"
	EthereumTxResponse   string = "ethereum/tx/response"
	MeshtasticWalletId   string = "meshtastic/wallet/id"
	MeshtasticWalletInfo string = "meshtastic/wallet/info"
)
