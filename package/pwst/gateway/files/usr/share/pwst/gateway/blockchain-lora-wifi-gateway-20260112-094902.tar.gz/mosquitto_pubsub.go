package main

import (
	"context"
	"os"
	"os/signal"
	"pwstgateway/gomeshradio"
	"pwstgateway/gotopics"
	"sync"
	"syscall"
	// Local modules
	log "pwstgateway/gologger"
	"pwstgateway/gomqttclient"
	"pwstgateway/gopub"
	"pwstgateway/gosub"
	"strconv"
	// From outside modules
	"github.com/joho/godotenv"
	"github.com/spf13/cobra"
)

/*
Main function initializing the MQTT client and start the Pub/Sub on the Mosquitto
server.
*/
func main() {
	var envFile string

	/***************************************************************************
	* CLI and Root command definition in case everything all right and in case
	 * of error
	***************************************************************************/
	var rootCmd = &cobra.Command{
		Use:   "mosquitto_pubsub",
		Short: "Start the Pub/Sub to Mosquitto server",
		// What to do when the command is called
		Run: func(cmd *cobra.Command, args []string) {
			err := godotenv.Load(envFile)
			if err != nil {
				log.Error.Println(
					"Error loading .env file\n",
				)
				os.Exit(1)
			}

			// Retrieve MQTT connection parameters from environment variables
			var broker = os.Getenv("BROKER")
			var portStr = os.Getenv("PORT")
			var portUint64 uint64
			var portParsingError error
			portUint64, portParsingError = strconv.ParseUint(
				portStr,
				10,
				16,
			)
			if portParsingError != nil {
				log.Error.Printf(
					"Error parsing PORT: %v\n",
					portParsingError,
				)
				os.Exit(1)
			}
			var port = uint16(portUint64)
			var clientID = os.Getenv("CLIENT_ID")
			var username = os.Getenv("USERNAME")
			var password = os.Getenv("PASSWORD")
			// Meshtastic device serial port
			var meshtasticSerialPort = os.Getenv("MESHTASTIC_SERIAL_PORT")
			//ETH provider
			var ethProviderURL = os.Getenv("ETH_PROVIDER_URL")

			log.Info.Printf(
				"Connecting to Wi-Fi gateway %v port %v\n",
				broker,
				port,
			)
			/*******************************************************************
			 * Instantiate a new MQTT client and connect to the broker
			 * *gomqttclient.MQTTClient is a pointer to MQTTClient.
			 ******************************************************************/
			mqttClient := gomqttclient.NewMQTTClient(
				broker,
				port,
				clientID,
				username,
				password,
			)
			/*******************************************************************
			 * TODO: Add your publish/subscribe logic here in GOROUTINES
			 ******************************************************************/
			// Create a context with cancellation to control goroutine
			ctx, cancel := context.WithCancel(context.Background())

			// Use a WaitGroup to ensure goroutines finish before closing resources
			var wg sync.WaitGroup

			// Publication
			//go gopub.PublishTime(ctx, mqttClient)
			//log.Info.Println(
			//	"Start go routine publishing time every second on topic %s",
			//	gotopics.TimeNow,
			//)
			wg.Add(1)
			go func() {
				defer wg.Done()
				gopub.PublishReceivedMeshtasticRx(
					ctx,
					mqttClient,
					meshtasticSerialPort,
				)
			}()
			log.Info.Println(
				"Start go routine connection Meshtastic device and publishing some payloads second on topic %s",
				gotopics.MeshtasticTx,
			)

			// Subscription
			//go gosub.SubscribeTime(ctx, mqttClient)
			//log.Info.Println(
			//	"Start go routine subscribing on topic %s",
			//	gotopics.TimeNow,
			//)
			wg.Add(1)
			go func() {
				defer wg.Done()
				gosub.SubscribeMeshtasticTx(
					ctx,
					mqttClient,
					ethProviderURL,
				)
			}()
			log.Info.Println(
				"Start go routine subscribing on topic %s and post Tx on blockchain",
				gotopics.MeshtasticTx,
			)
			wg.Add(1)
			go func() {
				defer wg.Done()
				gosub.SubscribeWalletInfo(
					ctx,
					mqttClient,
					ethProviderURL,
				)
			}()
			log.Info.Println(
				"Start go routine subscribing on topic %s for wallet info",
				gotopics.MeshtasticWalletId,
			)
			wg.Add(1)
			go func() {
				defer wg.Done()
				gosub.SubscribeEthereumTxResponse(ctx,
					mqttClient,
					meshtasticSerialPort,
				)
			}()
			log.Info.Println(
				"Start go routine subscribing on topic %s for Ethereum Tx response",
				gotopics.EthereumTxResponse,
			)
			wg.Add(1)
			go func() {
				defer wg.Done()
				gosub.SubscribeWalletInfoMeshtastic(
					ctx,
					mqttClient,
					meshtasticSerialPort,
				)
			}()
			/*******************************************************************
			 * Handling interruption signals for clean shutdown
			 ******************************************************************/
			// Create a channel to receive interruption signals
			sigChan := make(chan os.Signal, 1)
			// Register SIGINT (Ctrl+C) and SIGTERM signals
			signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
			log.Info.Println("Press Ctrl+C to stop...")
			// Wait until signal is received
			<-sigChan
			log.Info.Println("Interruption signal received")
			// Cancel context to stop goroutines
			cancel() // Signal goroutines to stop

			// Wait for all goroutines to finish cleanly before closing resources
			wg.Wait()

			// Close Meshtastic device connection
			gomeshradio.CloseRadio()
			/*******************************************************************
			 * Disconnection from the MQTT broker
			 ******************************************************************/
			mqttClient.Disconnect(1)
			log.Info.Println("Disconnected from MQTT broker")
		},
	}

	// Define flags and configuration settings
	rootCmd.Flags().StringVarP(
		&envFile,
		"env",                   // Flag name
		"e",                     // Short flag name
		"example.env",           // Default value
		"The .env file to load", // Description
	)

	// Execute the root command
	execCmdErr := rootCmd.Execute()
	if execCmdErr != nil {
		log.Error.Printf("Error executing command: %v", execCmdErr)
		os.Exit(1)
	}
}
