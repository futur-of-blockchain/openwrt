# Protobuf

All the protobuf descriptions of the project to be added as submodule to your project.

```
git submodule add git@github.com:futur-of-blockchain/shared-proto.git <desired folder name>
```

They are mandatory interfaces (Unless another serialization is more suitable).
The Protobuf descriptions are then self-describing the interfaces.

## Build

For any build the protoc compiler is required.

```shell
apt install -y protobuf-compiler
```
- MacOS:

```shell
brew install protobuf
```

### Build for Python

```shell
python -m pip install grpcio-tools
python -m grpc_tools.protoc -I=./ --python_out=./ *.proto
```

### Build for Go
    
```shell
go install google.golang.org/protobuf/cmd/protoc-gen-go@latest
protoc -I=./ --go_out=./ --go_opt=paths=source_relative *.proto
```