#!/usr/bin/env bash
rrdtool create mosquitto_pubsub.rrd \
--step 10 \
DS:cpu:GAUGE:20:0:100 \
DS:mem:GAUGE:20:0:U \
RRA:AVERAGE:0.5:1:8640 \
RRA:AVERAGE:0.5:30:2016