#!/usr/bin/env bash
GIT_HASH=$(git rev-parse --short HEAD 2>/dev/null || echo "no-git")

rrdtool graph mosquitto_pubsub.png \
  --start -2h \
  --title "Mosquitto Pub/Sub CPU and Memory Usage (last 2 hours) - ${GIT_HASH}" \
  --vertical-label "Usage" \
  DEF:cpu=./mosquitto_pubsub.rrd:cpu:AVERAGE \
  DEF:mem=./mosquitto_pubsub.rrd:mem:AVERAGE \
  LINE2:cpu#FF0000:"CPU %" \
  LINE2:mem#0000FF:"Memory (MB)" \
  COMMENT:"\n" \
  GPRINT:cpu:LAST:"Last CPU\: %5.2lf %%" \
  GPRINT:mem:LAST:"Last Mem\: %5.2lf MB\n" \
  GPRINT:cpu:AVERAGE:"Avg CPU\: %5.2lf %%" \
  GPRINT:mem:AVERAGE:"Avg Mem\: %5.2lf MB\n" \
  GPRINT:cpu:MAX:"Max CPU\: %5.2lf %%" \
  GPRINT:mem:MAX:"Max Mem\: %5.2lf MB\n"