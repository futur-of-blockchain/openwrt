#!/usr/bin/env bash
RRD="mosquitto_pubsub.rrd"

# Find PID of process
PID=$(pgrep -f mosquitto_pubsub | head -n1)
if [ -z "$PID" ]; then
    echo "Process not running"
    exit 1
fi

# Get CPU and memory usage
CPU=$(ps -p $PID -o %cpu= | awk '{print $1}')
MEM=$(ps -p $PID -o rss= | awk '{printf "%.2f", $1/1024}')  # MB

# Update the RRD
rrdtool update "$RRD" N:$CPU:$MEM
