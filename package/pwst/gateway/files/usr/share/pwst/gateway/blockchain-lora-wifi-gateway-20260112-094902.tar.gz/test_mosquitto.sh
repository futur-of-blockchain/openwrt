#!/usr/bin/env bash
mosquitto_pub -h localhost -p 1883 -t "test/persistence" -m "Message de test" | exit
